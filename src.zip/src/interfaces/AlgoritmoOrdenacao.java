package interfaces;

public interface AlgoritmoOrdenacao {
    String[] sort(String[] array, ComparadorAlgoritmoOrdenacao comparadorAlgoritmoOrdenacao);
}
