package interfaces;

public interface CasoAlgoritmoOrdenacao {
    String[] obterArray(String[] array, ComparadorAlgoritmoOrdenacao comparadorAlgoritmoOrdenacao);
}
