package interfaces;

public interface ComparadorAlgoritmoOrdenacao {
     int comparar(String a, String b);
}
